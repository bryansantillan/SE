/*
 * cdlocation_iface_v1.h
 *
 *  Created on: May 15, 2016
 *      Author: user
 */

#ifndef CDLOCATION_IFACE_V1_H_
#define CDLOCATION_IFACE_V1_H_

#include <public/cdlocation.h>

#endif /* CDLOCATION_IFACE_V1_H_ */
